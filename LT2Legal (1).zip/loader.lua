-- Main loader script
loadstring(game:HttpGet("https://raw.githubusercontent.com/<username>/LT2Legal/main/modules/ui.lua"))()
loadstring(game:HttpGet("https://raw.githubusercontent.com/<username>/LT2Legal/main/modules/tp.lua"))()
loadstring(game:HttpGet("https://raw.githubusercontent.com/<username>/LT2Legal/main/modules/utils.lua"))()
